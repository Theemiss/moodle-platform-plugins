// mod/tekouinvm/settings.php
<?php
defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {
    $settings->add(new admin_setting_configtext(
        'mod_tekouinvm/apiurl',
        get_string('apiurl', 'tekouinvm'),
        get_string('apiurl_desc', 'tekouinvm'),
        '',
        PARAM_URL
    ));

    $settings->add(new admin_setting_configtext(
        'mod_tekouinvm/apikey',
        get_string('apikey', 'tekouinvm'),
        get_string('apikey_desc', 'tekouinvm'),
        '',
        PARAM_ALPHANUM
    ));

    $settings->add(new admin_setting_configtext(
        'mod_tekouinvm/orgid',
        get_string('orgid', 'tekouinvm'),
        get_string('orgid_desc', 'tekouinvm'),
        '',
        PARAM_ALPHANUM
    ));
}