<?php
defined('MOODLE_INTERNAL') || die();

$string['includeusers'] = 'Include enrolled users';
$string['includecomments'] = 'Include comments';
$string['includelogs'] = 'Include logs';
$string['includeroleassignments'] = 'Include role assignments';

