<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External API for One Click Export
 *
 * @package     local_oneclickexport
 * @copyright   2024 Your Name <your@email.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_oneclickexport\external;

use external_api;
use external_function_parameters;
use external_value;
use external_single_structure;
use external_multiple_structure;
use moodle_exception;
use moodle_url;
use context_course;
use core_course_category;
use backup_controller;
use backup;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/backup/util/includes/backup_includes.php');
require_once($CFG->dirroot . '/course/lib.php');

class export_api extends external_api {

    /* ================= SINGLE COURSE EXPORT ================= */

    /**
     * Parameters for single course export
     */
    public static function export_single_course_parameters() {
        return new external_function_parameters([
            'courseid' => new external_value(PARAM_INT, 'ID of course to export'),
            'includefiles' => new external_value(PARAM_BOOL, 'Include course files', VALUE_DEFAULT, true),
            'includeusers' => new external_value(PARAM_BOOL, 'Include user data', VALUE_DEFAULT, false),
        ]);
    }

    /**
     * Execute single course export
     */
    public static function export_single_course($courseid, $includefiles, $includeusers) {
        global $USER, $DB;

        // Validate parameters
        $params = self::validate_parameters(self::export_single_course_parameters(), [
            'courseid' => $courseid,
            'includefiles' => $includefiles,
            'includeusers' => $includeusers
        ]);

        // Validate context and capabilities
        $context = context_course::instance($params['courseid']);
        self::validate_context($context);
        require_capability('local/oneclickexport:export', $context);

        // Setup environment
        self::setup_export_environment();

        try {
            // Create backup filename
            $course = get_course($params['courseid']);
            $filename = self::generate_backup_filename($course);

            // Configure backup settings
            $backupsettings = [
                'users' => $params['includeusers'] ? 1 : 0,
                'anonymize' => 0,
                'activities' => 1,
                'blocks' => 1,
                'filters' => 1,
                'files' => $params['includefiles'] ? 1 : 0,
            ];

            // Execute backup
            $result = self::execute_backup($course, $USER->id, $filename, $backupsettings);

            return [
                'success' => true,
                'courseid' => $course->id,
                'filename' => $result['filename'],
                'filesize' => $result['filesize'],
                'downloadurl' => $result['downloadurl'],
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'courseid' => $params['courseid'],
                'error' => $e->getMessage(),
            ];
        }
    }

    /**
     * Return structure for single export
     */
    public static function export_single_course_returns() {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Export status'),
            'courseid' => new external_value(PARAM_INT, 'Exported course ID'),
            'filename' => new external_value(PARAM_FILE, 'Backup filename', VALUE_OPTIONAL),
            'filesize' => new external_value(PARAM_INT, 'File size in bytes', VALUE_OPTIONAL),
            'downloadurl' => new external_value(PARAM_URL, 'Download URL', VALUE_OPTIONAL),
            'error' => new external_value(PARAM_TEXT, 'Error message', VALUE_OPTIONAL),
        ]);
    }

    /* ================= BULK COURSE EXPORT ================= */

    /**
     * Parameters for bulk export
     */
    public static function export_bulk_courses_parameters() {
        return new external_function_parameters([
            'courseids' => new external_multiple_structure(
                new external_value(PARAM_INT, 'Course ID'),
                'Array of course IDs to export'
            ),
            'includefiles' => new external_value(PARAM_BOOL, 'Include course files', VALUE_DEFAULT, true),
            'includeusers' => new external_value(PARAM_BOOL, 'Include user data', VALUE_DEFAULT, false),
        ]);
    }

    /**
     * Execute bulk export
     */
    public static function export_bulk_courses($courseids, $includefiles, $includeusers) {
        global $USER;

        // Validate parameters
        $params = self::validate_parameters(self::export_bulk_courses_parameters(), [
            'courseids' => $courseids,
            'includefiles' => $includefiles,
            'includeusers' => $includeusers
        ]);

        // Validate system capability
        require_capability('local/oneclickexport:bulkexport', \context_system::instance());

        // Setup environment
        self::setup_export_environment();

        $results = [];
        foreach ($params['courseids'] as $courseid) {
            try {
                // Check course exists and user has access
                $course = get_course($courseid);
                $context = context_course::instance($courseid);
                
                if (!has_capability('local/oneclickexport:export', $context)) {
                    throw new moodle_exception('nopermissiontoexport', 'local_oneclickexport');
                }

                // Create backup filename
                $filename = self::generate_backup_filename($course);

                // Configure backup settings
                $backupsettings = [
                    'users' => $params['includeusers'] ? 1 : 0,
                    'anonymize' => 0,
                    'activities' => 1,
                    'blocks' => 1,
                    'filters' => 1,
                    'files' => $params['includefiles'] ? 1 : 0,
                ];

                // Execute backup
                $result = self::execute_backup($course, $USER->id, $filename, $backupsettings);

                $results[] = [
                    'success' => true,
                    'courseid' => $course->id,
                    'filename' => $result['filename'],
                    'filesize' => $result['filesize'],
                    'downloadurl' => $result['downloadurl'],
                ];

            } catch (\Exception $e) {
                $results[] = [
                    'success' => false,
                    'courseid' => $courseid,
                    'error' => $e->getMessage(),
                ];
            }
        }

        return $results;
    }

    /**
     * Return structure for bulk export
     */
    public static function export_bulk_courses_returns() {
        return new external_multiple_structure(
            new external_single_structure([
                'success' => new external_value(PARAM_BOOL, 'Export status'),
                'courseid' => new external_value(PARAM_INT, 'Exported course ID'),
                'filename' => new external_value(PARAM_FILE, 'Backup filename', VALUE_OPTIONAL),
                'filesize' => new external_value(PARAM_INT, 'File size in bytes', VALUE_OPTIONAL),
                'downloadurl' => new external_value(PARAM_URL, 'Download URL', VALUE_OPTIONAL),
                'error' => new external_value(PARAM_TEXT, 'Error message', VALUE_OPTIONAL),
            ])
        );
    }

    /* ================= COURSE LISTING ================= */

    /**
     * Parameters for course listing
     */
    public static function list_exportable_courses_parameters() {
        return new external_function_parameters([
            'categoryid' => new external_value(PARAM_INT, 'Category ID to filter', VALUE_DEFAULT, 0),
            'search' => new external_value(PARAM_TEXT, 'Search term', VALUE_DEFAULT, ''),
            'limit' => new external_value(PARAM_INT, 'Maximum results to return', VALUE_DEFAULT, 50),
            'offset' => new external_value(PARAM_INT, 'Result offset', VALUE_DEFAULT, 0),
        ]);
    }

    /**
     * Get list of exportable courses
     */
    public static function list_exportable_courses($categoryid, $search, $limit, $offset) {
        global $USER;

        // Validate parameters
        $params = self::validate_parameters(self::list_exportable_courses_parameters(), [
            'categoryid' => $categoryid,
            'search' => $search,
            'limit' => $limit,
            'offset' => $offset
        ]);

        // Get courses based on filters
        $courses = self::get_filtered_courses($params['categoryid'], $params['search'], $params['limit'], $params['offset']);

        $result = [];
        foreach ($courses as $course) {
            $context = context_course::instance($course->id);
            $canexport = has_capability('local/oneclickexport:export', $context);

            $result[] = [
                'id' => $course->id,
                'shortname' => $course->shortname,
                'fullname' => format_string($course->fullname),
                'categoryid' => $course->category,
                'categoryname' => format_string($course->categoryname),
                'exportable' => $canexport,
                'visible' => (bool)$course->visible,
            ];
        }

        return $result;
    }

    /**
     * Return structure for course listing
     */
    public static function list_exportable_courses_returns() {
        return new external_multiple_structure(
            new external_single_structure([
                'id' => new external_value(PARAM_INT, 'Course ID'),
                'shortname' => new external_value(PARAM_TEXT, 'Course shortname'),
                'fullname' => new external_value(PARAM_TEXT, 'Course full name'),
                'categoryid' => new external_value(PARAM_INT, 'Category ID'),
                'categoryname' => new external_value(PARAM_TEXT, 'Category name'),
                'exportable' => new external_value(PARAM_BOOL, 'Whether user can export this course'),
                'visible' => new external_value(PARAM_BOOL, 'Course visibility status'),
            ])
        );
    }

    /* ================= HELPER METHODS ================= */

    /**
     * Setup environment for export operations
     */
    protected static function setup_export_environment() {
        @set_time_limit(0);
        raise_memory_limit(MEMORY_EXTRA);
        core_php_time_limit::raise();
    }

    /**
     * Generate backup filename
     */
    protected static function generate_backup_filename($course) {
        return clean_filename($course->shortname . '-backup-' . date('Ymd-His') . '.mbz');
    }

    /**
     * Execute the backup process
     */
    protected static function execute_backup($course, $userid, $filename, $settings) {
        $bc = new backup_controller(
            backup::TYPE_1COURSE,
            $course->id,
            backup::FORMAT_MOODLE,
            backup::INTERACTIVE_NO,
            backup::MODE_GENERAL,
            $userid
        );

        try {
            // Apply backup settings
            $plan = $bc->get_plan();
            foreach ($settings as $name => $value) {
                if ($plan->setting_exists($name)) {
                    $plan->get_setting($name)->set_value($value);
                }
            }
            $plan->get_setting('filename')->set_value($filename);

            // Execute backup
            $bc->execute_plan();
            $results = $bc->get_results();
            $file = $results['backup_destination'];

            if (!$file) {
                throw new moodle_exception('nobackupfile', 'local_oneclickexport');
            }

            // Generate download URL
            $downloadurl = moodle_url::make_webservice_pluginfile_url(
                $file->get_contextid(),
                $file->get_component(),
                $file->get_filearea(),
                $file->get_itemid(),
                $file->get_filepath(),
                $file->get_filename(),
                true
            )->out(false);

            return [
                'filename' => $file->get_filename(),
                'filesize' => $file->get_filesize(),
                'downloadurl' => $downloadurl,
            ];

        } finally {
            $bc->destroy();
            unset($bc);
        }
    }

    /**
     * Get filtered list of courses
     */
    protected static function get_filtered_courses($categoryid, $search, $limit, $offset) {
        global $DB;

        $params = [];
        $where = ['c.id <> :siteid'];
        $params['siteid'] = SITEID;

        // Filter by category if specified
        if (!empty($categoryid)) {
            $where[] = 'c.category = :categoryid';
            $params['categoryid'] = $categoryid;
        }

        // Apply search if specified
        if (!empty($search)) {
            $where[] = $DB->sql_like('c.fullname', ':search', false) . ' OR ' . 
                       $DB->sql_like('c.shortname', ':search2', false);
            $params['search'] = '%' . $DB->sql_like_escape($search) . '%';
            $params['search2'] = '%' . $DB->sql_like_escape($search) . '%';
        }

        $wheresql = implode(' AND ', $where);

        $sql = "SELECT c.id, c.shortname, c.fullname, c.category, c.visible, 
                       cc.name as categoryname
                FROM {course} c
                JOIN {course_categories} cc ON cc.id = c.category
                WHERE $wheresql
                ORDER BY c.fullname ASC";

        return $DB->get_records_sql($sql, $params, $offset, $limit);
    }
}