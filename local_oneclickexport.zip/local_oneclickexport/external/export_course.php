<?php
// This is a protection against direct access
defined('MOODLE_INTERNAL') || die();

namespace local_oneclickexport\external;

use external_api;
use external_function_parameters;
use external_value;
use external_single_structure;
use moodle_url;
use moodle_exception;

require_once($CFG->dirroot.'/backup/util/includes/backup_includes.php');

class export_course extends external_api {

    public static function execute_parameters() {
        return new external_function_parameters([
            'courseid' => new external_value(PARAM_INT, 'ID of course to export')
        ]);
    }

    public static function execute($courseid) {
        global $USER, $DB;

        // Validate parameters
        $params = self::validate_parameters(self::execute_parameters(), ['courseid' => $courseid]);
        $courseid = $params['courseid'];

        // Validate context and capabilities
        $context = \context_course::instance($courseid);
        self::validate_context($context);
        require_capability('local/oneclickexport:export', $context);

        // Setup environment for large operations
        @set_time_limit(0);
        raise_memory_limit(MEMORY_HUGE);

        $userid = $USER->id;
        $course = get_course($courseid);
        $bc = null;

        try {
            // Create backup controller
            $bc = new \backup_controller(
                \backup::TYPE_1COURSE,
                $course->id,
                \backup::FORMAT_MOODLE,
                \backup::INTERACTIVE_NO,
                \backup::MODE_GENERAL,
                $userid
            );

            // Configure backup settings
            $this->configure_backup_settings($bc, $course);

            // Execute backup
            $bc->execute_plan();
            $results = $bc->get_results();
            $file = $results['backup_destination'];

            if (!$file) {
                throw new moodle_exception('nobackupfile', 'local_oneclickexport');
            }

            // Generate download URL
            $url = moodle_url::make_webservice_pluginfile_url(
                $file->get_contextid(),
                $file->get_component(),
                $file->get_filearea(),
                $file->get_itemid(),
                $file->get_filepath(),
                $file->get_filename(),
                true
            )->out(false);

            return [
                'success' => true,
                'filename' => $file->get_filename(),
                'url' => $url
            ];

        } catch (\Exception $e) {
            throw new moodle_exception('backuperror', 'local_oneclickexport', '', $e->getMessage());
        } finally {
            // Always destroy the backup controller to release resources
            if ($bc instanceof \backup_controller) {
                $bc->destroy();
            }
        }
    }

    /**
     * Configures the backup settings
     */
    protected static function configure_backup_settings($bc, $course) {
        $plan = $bc->get_plan();
        
        // Default settings
        $settings = [
            'users' => 0,        // Don't include users
            'anonymize' => 0,     // Don't anonymize
            'activities' => 1,    // Include activities
            'blocks' => 1,        // Include blocks
            'filters' => 1        // Include filters
        ];

        foreach ($settings as $name => $value) {
            if ($plan->setting_exists($name)) {
                $plan->get_setting($name)->set_value($value);
            }
        }

        // Set filename
        $filename = clean_filename($course->shortname . '-backup-' . date('Ymd-His') . '.mbz');
        $plan->get_setting('filename')->set_value($filename);
    }

    public static function execute_returns() {
        return new external_single_structure([
            'success' => new external_value(PARAM_BOOL, 'Was export successful'),
            'filename' => new external_value(PARAM_FILE, 'Exported MBZ filename'),
            'url' => new external_value(PARAM_URL, 'Download URL for exported MBZ')
        ]);
    }
}