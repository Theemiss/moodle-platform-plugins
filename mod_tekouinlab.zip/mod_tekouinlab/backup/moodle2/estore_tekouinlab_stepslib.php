<?php
class restore_tekouinlab_activity_structure_step extends restore_activity_structure_step {
    protected function define_structure() {
        $paths = [];
        $paths[] = new restore_path_element('tekouinlab', '/activity/tekouinlab');

        return $this->prepare_activity_structure($paths);
    }

    protected function process_tekouinlab($data) {
        global $DB;

        $data = (object)$data;
        $data->course = $this->get_courseid();
        $newitemid = $DB->insert_record('tekouinlab', $data);
        $this->apply_activity_instance($newitemid);
    }
}